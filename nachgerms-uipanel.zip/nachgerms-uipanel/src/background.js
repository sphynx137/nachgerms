// NachGerms — background.js
// Minimal Manifest V3 service worker.
// Color sync between popup and content scripts is handled via
// chrome.storage.onChanged (no message passing needed).
// This file is reserved for future features such as
// declarativeNetRequest rules or cross-tab coordination.
